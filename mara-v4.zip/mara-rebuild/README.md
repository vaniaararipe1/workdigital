# Mara Embalagens — Fase 1 V4

Protótipo HTML/CSS/JS. Sem WordPress/PHP/CMS.

## Correções V4
- logo oficial fornecido pela cliente, salvo localmente em `public/images/`
- vermelho oficial extraído do SVG fornecido: `#E63448`
- amarelo removido do sistema visual
- Montserrat carregada via Google Fonts no protótipo
- navegação com dropdowns institucionais e de soluções
- páginas adicionadas: Flexocromi, Certificações e Política de Qualidade
- links globais e menu mobile atualizados

## Páginas
Home, Quem Somos, Estrutura, Premiações, Certificações, Política de Qualidade, Produtos, Flexocromi, Caixas de Papelão, Projetos Especiais, Blog, Artigo, Contato e Trabalhe Conosco.
